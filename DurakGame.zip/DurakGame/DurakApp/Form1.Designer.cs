﻿namespace DurakApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DeckBox = new System.Windows.Forms.PictureBox();
            this.DeckLabel = new System.Windows.Forms.Label();
            this.PlayerCard_2 = new System.Windows.Forms.PictureBox();
            this.PlayerCard_3 = new System.Windows.Forms.PictureBox();
            this.PlayerCard_4 = new System.Windows.Forms.PictureBox();
            this.PlayerCard_5 = new System.Windows.Forms.PictureBox();
            this.PlayerCard_6 = new System.Windows.Forms.PictureBox();
            this.PlayerCard_1 = new System.Windows.Forms.PictureBox();
            this.playerLabel = new System.Windows.Forms.Label();
            this.TrumpBox = new System.Windows.Forms.PictureBox();
            this.TrumpLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.P2Card_1 = new System.Windows.Forms.PictureBox();
            this.P2Card_6 = new System.Windows.Forms.PictureBox();
            this.P2Card_5 = new System.Windows.Forms.PictureBox();
            this.P2Card_4 = new System.Windows.Forms.PictureBox();
            this.P2Card_3 = new System.Windows.Forms.PictureBox();
            this.P2Card_2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.DeckBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCard_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCard_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCard_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCard_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCard_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCard_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrumpBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.P2Card_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.P2Card_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.P2Card_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.P2Card_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.P2Card_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.P2Card_2)).BeginInit();
            this.SuspendLayout();
            // 
            // DeckBox
            // 
            this.DeckBox.Image = global::DurakApp.Properties.Resources.gray_back;
            this.DeckBox.Location = new System.Drawing.Point(12, 12);
            this.DeckBox.Name = "DeckBox";
            this.DeckBox.Size = new System.Drawing.Size(144, 195);
            this.DeckBox.TabIndex = 0;
            this.DeckBox.TabStop = false;
            this.DeckBox.Click += new System.EventHandler(this.DeckBox_Click);
            // 
            // DeckLabel
            // 
            this.DeckLabel.AutoSize = true;
            this.DeckLabel.Location = new System.Drawing.Point(12, 210);
            this.DeckLabel.Name = "DeckLabel";
            this.DeckLabel.Size = new System.Drawing.Size(33, 13);
            this.DeckLabel.TabIndex = 1;
            this.DeckLabel.Text = "Deck";
            this.DeckLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // PlayerCard_2
            // 
            this.PlayerCard_2.Image = global::DurakApp.Properties.Resources.QS;
            this.PlayerCard_2.Location = new System.Drawing.Point(427, 582);
            this.PlayerCard_2.Name = "PlayerCard_2";
            this.PlayerCard_2.Size = new System.Drawing.Size(149, 221);
            this.PlayerCard_2.TabIndex = 2;
            this.PlayerCard_2.TabStop = false;
            // 
            // PlayerCard_3
            // 
            this.PlayerCard_3.Image = global::DurakApp.Properties.Resources.QS;
            this.PlayerCard_3.Location = new System.Drawing.Point(582, 582);
            this.PlayerCard_3.Name = "PlayerCard_3";
            this.PlayerCard_3.Size = new System.Drawing.Size(149, 221);
            this.PlayerCard_3.TabIndex = 3;
            this.PlayerCard_3.TabStop = false;
            // 
            // PlayerCard_4
            // 
            this.PlayerCard_4.Image = global::DurakApp.Properties.Resources.QS;
            this.PlayerCard_4.Location = new System.Drawing.Point(737, 582);
            this.PlayerCard_4.Name = "PlayerCard_4";
            this.PlayerCard_4.Size = new System.Drawing.Size(149, 221);
            this.PlayerCard_4.TabIndex = 4;
            this.PlayerCard_4.TabStop = false;
            // 
            // PlayerCard_5
            // 
            this.PlayerCard_5.Image = global::DurakApp.Properties.Resources.QS;
            this.PlayerCard_5.Location = new System.Drawing.Point(892, 582);
            this.PlayerCard_5.Name = "PlayerCard_5";
            this.PlayerCard_5.Size = new System.Drawing.Size(149, 221);
            this.PlayerCard_5.TabIndex = 5;
            this.PlayerCard_5.TabStop = false;
            // 
            // PlayerCard_6
            // 
            this.PlayerCard_6.Image = global::DurakApp.Properties.Resources.QS;
            this.PlayerCard_6.Location = new System.Drawing.Point(1047, 582);
            this.PlayerCard_6.Name = "PlayerCard_6";
            this.PlayerCard_6.Size = new System.Drawing.Size(149, 221);
            this.PlayerCard_6.TabIndex = 6;
            this.PlayerCard_6.TabStop = false;
            // 
            // PlayerCard_1
            // 
            this.PlayerCard_1.Image = global::DurakApp.Properties.Resources.QS;
            this.PlayerCard_1.Location = new System.Drawing.Point(272, 582);
            this.PlayerCard_1.Name = "PlayerCard_1";
            this.PlayerCard_1.Size = new System.Drawing.Size(149, 221);
            this.PlayerCard_1.TabIndex = 7;
            this.PlayerCard_1.TabStop = false;
            // 
            // playerLabel
            // 
            this.playerLabel.AutoSize = true;
            this.playerLabel.Location = new System.Drawing.Point(695, 566);
            this.playerLabel.Name = "playerLabel";
            this.playerLabel.Size = new System.Drawing.Size(65, 13);
            this.playerLabel.TabIndex = 8;
            this.playerLabel.Text = "Player Hand";
            // 
            // TrumpBox
            // 
            this.TrumpBox.Image = global::DurakApp.Properties.Resources.QS;
            this.TrumpBox.Location = new System.Drawing.Point(10, 229);
            this.TrumpBox.Name = "TrumpBox";
            this.TrumpBox.Size = new System.Drawing.Size(146, 195);
            this.TrumpBox.TabIndex = 9;
            this.TrumpBox.TabStop = false;
            // 
            // TrumpLabel
            // 
            this.TrumpLabel.AutoSize = true;
            this.TrumpLabel.Location = new System.Drawing.Point(12, 427);
            this.TrumpLabel.Name = "TrumpLabel";
            this.TrumpLabel.Size = new System.Drawing.Size(58, 13);
            this.TrumpLabel.TabIndex = 10;
            this.TrumpLabel.Text = "Trump Suit";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(695, 236);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "AI Player Hand";
            // 
            // P2Card_1
            // 
            this.P2Card_1.Image = global::DurakApp.Properties.Resources.QS;
            this.P2Card_1.Location = new System.Drawing.Point(272, 12);
            this.P2Card_1.Name = "P2Card_1";
            this.P2Card_1.Size = new System.Drawing.Size(149, 221);
            this.P2Card_1.TabIndex = 16;
            this.P2Card_1.TabStop = false;
            // 
            // P2Card_6
            // 
            this.P2Card_6.Image = global::DurakApp.Properties.Resources.QS;
            this.P2Card_6.Location = new System.Drawing.Point(1047, 12);
            this.P2Card_6.Name = "P2Card_6";
            this.P2Card_6.Size = new System.Drawing.Size(149, 221);
            this.P2Card_6.TabIndex = 15;
            this.P2Card_6.TabStop = false;
            // 
            // P2Card_5
            // 
            this.P2Card_5.Image = global::DurakApp.Properties.Resources.QS;
            this.P2Card_5.Location = new System.Drawing.Point(892, 12);
            this.P2Card_5.Name = "P2Card_5";
            this.P2Card_5.Size = new System.Drawing.Size(149, 221);
            this.P2Card_5.TabIndex = 14;
            this.P2Card_5.TabStop = false;
            // 
            // P2Card_4
            // 
            this.P2Card_4.Image = global::DurakApp.Properties.Resources.QS;
            this.P2Card_4.Location = new System.Drawing.Point(737, 12);
            this.P2Card_4.Name = "P2Card_4";
            this.P2Card_4.Size = new System.Drawing.Size(149, 221);
            this.P2Card_4.TabIndex = 13;
            this.P2Card_4.TabStop = false;
            // 
            // P2Card_3
            // 
            this.P2Card_3.Image = global::DurakApp.Properties.Resources.QS;
            this.P2Card_3.Location = new System.Drawing.Point(582, 12);
            this.P2Card_3.Name = "P2Card_3";
            this.P2Card_3.Size = new System.Drawing.Size(149, 221);
            this.P2Card_3.TabIndex = 12;
            this.P2Card_3.TabStop = false;
            // 
            // P2Card_2
            // 
            this.P2Card_2.Image = global::DurakApp.Properties.Resources.QS;
            this.P2Card_2.Location = new System.Drawing.Point(427, 12);
            this.P2Card_2.Name = "P2Card_2";
            this.P2Card_2.Size = new System.Drawing.Size(149, 221);
            this.P2Card_2.TabIndex = 11;
            this.P2Card_2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1290, 815);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.P2Card_1);
            this.Controls.Add(this.P2Card_6);
            this.Controls.Add(this.P2Card_5);
            this.Controls.Add(this.P2Card_4);
            this.Controls.Add(this.P2Card_3);
            this.Controls.Add(this.P2Card_2);
            this.Controls.Add(this.TrumpLabel);
            this.Controls.Add(this.TrumpBox);
            this.Controls.Add(this.playerLabel);
            this.Controls.Add(this.PlayerCard_1);
            this.Controls.Add(this.PlayerCard_6);
            this.Controls.Add(this.PlayerCard_5);
            this.Controls.Add(this.PlayerCard_4);
            this.Controls.Add(this.PlayerCard_3);
            this.Controls.Add(this.PlayerCard_2);
            this.Controls.Add(this.DeckLabel);
            this.Controls.Add(this.DeckBox);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.DeckBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCard_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCard_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCard_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCard_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCard_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerCard_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrumpBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.P2Card_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.P2Card_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.P2Card_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.P2Card_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.P2Card_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.P2Card_2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox DeckBox;
        private System.Windows.Forms.Label DeckLabel;
        private System.Windows.Forms.PictureBox PlayerCard_2;
        private System.Windows.Forms.PictureBox PlayerCard_3;
        private System.Windows.Forms.PictureBox PlayerCard_4;
        private System.Windows.Forms.PictureBox PlayerCard_5;
        private System.Windows.Forms.PictureBox PlayerCard_6;
        private System.Windows.Forms.PictureBox PlayerCard_1;
        private System.Windows.Forms.Label playerLabel;
        private System.Windows.Forms.PictureBox TrumpBox;
        private System.Windows.Forms.Label TrumpLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox P2Card_1;
        private System.Windows.Forms.PictureBox P2Card_6;
        private System.Windows.Forms.PictureBox P2Card_5;
        private System.Windows.Forms.PictureBox P2Card_4;
        private System.Windows.Forms.PictureBox P2Card_3;
        private System.Windows.Forms.PictureBox P2Card_2;
    }
}

